# imports
import csv
import os
import difflib
import sys
import pathlib
import smtplib
from os.path import basename
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime
from email.utils import formatdate

# google api imports
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow

# global variables
scopes = ['https://www.googleapis.com/auth/spreadsheets']

token_file = 'token.json'

dir = pathlib.Path().resolve()
log_folder = str(dir)+'/log/'


def GetCSV(file_name, line=0):  # retrieves data from CSV
    with open(file_name) as opened_file:
        ctr = 1
        csv_file = csv.reader(opened_file)
        csv_data = []
        for row in csv_file:  # goes row by row taking data form
            if line != 0:  # CSV and putting it in a list
                if ctr == line:
                    csv_data = row
                    break
                ctr += 1
            else:
                csv_data.append(row)
        return csv_data


# Below variables retrieve data from 'options.csv' and
# puts it into corresponding lists for each group of
# options that would normally be on the Google Form.

# This section of options is specifically reserved for
# options that aren't based other options that get chosen.
names = sorted((GetCSV('options.csv', 1)))
service_types = GetCSV('options.csv', 2)
schools = sorted((GetCSV('options.csv', 3)))
laptops = GetCSV('options.csv', 4)
ipads = GetCSV('options.csv', 5)
dmg_type = GetCSV('options.csv', 6)

devices = laptops + ipads

# This section is reserved for options that are
# conditional and in this case one of these will
# be chosen based on which model is chosen.
g6 = GetCSV('options.csv', 7)
g7 = GetCSV('options.csv', 8)
g8 = GetCSV('options.csv', 9)
g9 = GetCSV('options.csv', 10)
lenovo = GetCSV('options.csv', 11)
dell_2_in_1 = GetCSV('options.csv', 12)
dell_e_rate = GetCSV('options.csv', 13)
latitude = GetCSV('options.csv', 14)
ipad5 = GetCSV('options.csv', 15)
ipad6 = GetCSV('options.csv', 16)
ipad7 = GetCSV('options.csv', 17)
ipad8 = GetCSV('options.csv', 18)
ipad9 = GetCSV('options.csv', 19)


# Simple method that compares a string to a list and chooses
# the string in that list that is the most similar to the
# compared string (unless the string is too different).
def MatchString(string, string_list):
    return difflib.get_close_matches(string, string_list, 1)


# The method that actualy handles modifying the Google
# form, provided courtesy of Googles API documentation
# and modified by me for our use case
def AppendValues(spreadsheet_id, row_to_log, token_file):

    creds = None

    # Assures required files for authentification are available.
    if os.path.exists(token_file):
        creds = Credentials.from_authorized_user_file(token_file, scopes)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', scopes)
            creds = flow.run_local_server(port=0)
        with open(token_file, 'w') as token_file:
            token_file.write(creds.to_json())

    try:  # The portion of the code that actually puts data into the Sheet.
        service = build('sheets', 'v4', credentials=creds)

        values = [row_to_log]
        body = {
            'values': values
        }
        result = service.spreadsheets().values().append(
            spreadsheetId=spreadsheet_id, range=r"'Form Responses 1'!A1:C2",
            valueInputOption="USER_ENTERED", body=body).execute()
        return result

    except HttpError as error:  # Simple error handling
        print(f"An error occurred: {error}")
        return error


# Retrieves 1st line in 'input.csv' and uses thtavalue as the name.
# It then takes that name and correts it if it contains any typos
# using the 'MatchString' method. Afterwards it inserts the corrected
# name into each row of the CSV.
def SetName(csv_data):
    ctr = 0
    name = str(csv_data[0][0])
    name_match = MatchString(name, names)
    modified_csv_data = []
    for row in csv_data:
        if ctr == 0:
            ctr += 1
            continue
        else:
            row.insert(0, name_match[0])
            modified_csv_data.append(row)
    return modified_csv_data


# Parses the parts provided in 'input.csv',
# corrects typos using the 'MatchString' method,
# then puts it back into its final string.
def PartParse(parts, part_options):
    parts_list = parts.split('+')
    parsed_parts = ''

    for part in parts_list:
        match_part = MatchString(part, part_options)
        if parts_list.index(part) == len(parts_list)-1:
            if len(match_part) == 0 and part[0] == '!':
                parsed_parts += part[1:]
            else:
                parsed_parts += match_part[0]
        else:
            parsed_parts += match_part[0] + ', '
    return parsed_parts


# Checks if an NISD # is less than 6, if so then stops
# execution of the program and warns the user.
def CheckNISDNumValid(nisd_num, ctr):
    if len(nisd_num) < 6:
        print('| \"input.csv\" | Error with CSV at line ' + str(ctr) +
              ', column 2 | Value name: NISD # | NISD # too short |')
        sys.exit()


# Uses 'MatchString' to correct typos in model name, then
# uses the corrected model name to select a parts list.
def GetModelInfo(model, opt=0):
    match_model = MatchString(model, devices)
    match_model = match_model[0]

    if match_model == 'Chromebook G6 EE':
        model_part_list = g6
    elif match_model == 'Chromebook G7 EE':
        model_part_list = g7
    elif match_model == 'Chromebook G8 11 EE (Touchscreen)':
        model_part_list = g8
    elif match_model == 'Chromebook G8 11/11A EE (Non-Touchscreen)':
        model_part_list = g8
    elif match_model == 'Chromebook G8 11A EE (E-RATE) (Non-Touchscreen)':
        model_part_list = g8
    elif match_model == 'Chromebook G9 11MK EE':
        model_part_list = g9
    elif match_model == 'Chromebook Lenovo 14e':
        model_part_list = lenovo
    elif match_model == 'Chromebook 3100 2-in-1':
        model_part_list = dell_2_in_1
    elif match_model == 'Chromebook 3100 (E-RATE)':
        model_part_list = dell_e_rate
    elif match_model == 'Latitude 3190 2-in-1':
        model_part_list = latitude
    elif match_model == 'iPad 5 (1822)':
        model_part_list = ipad5
    elif match_model == 'iPad 6 (1893)':
        model_part_list = ipad6
    elif match_model == 'iPad 7 (2197)':
        model_part_list = ipad7
    elif match_model == 'iPad 8 (2270)':
        model_part_list = ipad8
    elif match_model == 'iPad 9 (2602)':
        model_part_list = ipad9

    if opt == 0:
        return match_model
    elif opt == 1:
        return model_part_list


def AddBlanks(data, pos, opt=0):  # Inserts blank columns
    new_data = []
    if opt == 0:
        for row in data:
            row.insert(pos, '')
            new_data.append(row)
        return new_data
    if opt == 1:
        data.insert(pos, '')
        return data


def SanitizeInput(csv_data):  # Cleans CSV input up and corrects typos
    #    try:
    # Variables to store corrected values.
    ctr = 1
    service_match = ''
    school_match = ''
    dmg_type_match = ''

    # Variables to get information about
    # what part of CSV caused the crash.
    school_err = 0
    service_err = 0
    name_err = 0
    part_err = 0
    model_err = 0
    dmg_type_err = 0

    modified_csv_data = []
    for row in csv_data:  # Loops through data and corrects typos.
        ctr += 1

        if ctr == 2:  # Skips name
            continue

        # Corrects service type, school name,
        # and damage type found in the CSV.
        service_match = MatchString(row[0], service_types)
        school_match = MatchString(row[2], schools)
        dmg_type_match = MatchString(row[5], dmg_type)

        # Assigns corrected service type to position 1 of the row.
        service_err = 1
        row[0] = service_match[0]
        service_err = 0

        # Calls 'CheckNISDNumValid' to verify validity of NISD #
        CheckNISDNumValid(row[1], ctr)

        # Assigns corrected school name to position 3 of the row.
        school_err = 1
        row[2] = school_match[0]
        school_err = 0

        # Assigns corrected model name to position 4 of the
        # row and retrieves the part list that matches that model.
        model_err = 1
        row[3] = GetModelInfo(row[3])
        model_list = GetModelInfo(row[3], 1)
        model_err = 0

        # Assigns corrected part name to position 5 of the row.
        part_err = 1
        row[4] = PartParse(row[4], model_list)
        part_err = 0

        # Assigns corrected damage option to position 6 of the row.
        dmg_type_err = 1
        row[5] = dmg_type_match[0]
        dmg_type_err = 0

        # Adds the modified row to a new list of rows.
        modified_csv_data.append(row)

    # Calls 'SetName' to correct name and add it to the data set.
    name_err = 1
    modified_csv_data = SetName(csv_data)
    name_err = 0

    return modified_csv_data

    # Handles when the CSV data is too different from
    # values in the list and outputs information regarding
    # the value causing the issue (name of value, the
    # row and the column of the culprit)
    """
    except IndexError:
        if service_err == 1:
            issue = [1, 'Repair Type']
        elif name_err == 1:
            issue = [1, 'Technician Name']
        elif school_err == 1:
            issue = [3, 'School Name']
        elif model_err == 1:
            issue = [4, 'Model']
        elif part_err == 1:
            issue = [5, 'Parts']
        elif dmg_type_err == 1:
            issue = [6, 'Damage Type']
        else:
            issue = ['[Unknown]', '[Unknown]']

        # The above mentioned error message.
        message = '| \"input.csv\" | Error with CSV at line ' + \
            str(ctr) + ', column ' + \
            str(issue[0]) + ' | Value name: ' + issue[1] + ' |'

        print(message)
        sys.exit()  # Stops execution
"""

# Gets current time and adds it to the data.


def InsertDates(modified_csv_data):
    new_csv_data = []
    for row in modified_csv_data:
        now = datetime.now()
        time = now.strftime("%m/%d/%Y %H:%M:%S")
        row.insert(0, str(time))
        new_csv_data.append(row)
    return new_csv_data

# Calls other functions responsible for formatting data
# and producing the final sanitized/corrected data


def FormatCSVData(file_name):
    # Calls 'GetCSV' to retrieve data from the original CSV
    csv_data = GetCSV(file_name)

    # Calls 'SanitizeInput' to clean up the input data
    modified_csv_data = SanitizeInput(csv_data)

    # Calls 'InsertDates' to add dates to the formatted data
    modified_csv_data = InsertDates(modified_csv_data)

    # Calls 'AddBlanks' put blanks in the E-Rate column

    return modified_csv_data


def CreateCSV(csv_data):  # Saves the data in CSV format to the log folder

    # Defines variables for easy naming of the file and its path.
    now = datetime.now()
    created = False
    time = now.strftime("%m-%d-%Y")
    ctr = 1
    file_path = log_folder+time+'-repair-log('+str(ctr)+').csv'

    # Checks if file and folder exists, if not it creates the file/folder
    if not os.path.exists(log_folder):
        os.mkdir(log_folder)
    while created is False:
        if not os.path.exists(log_folder+time+'-repair-log('+str(ctr)+').csv'):
            open(log_folder+time+'-repair-log('+str(ctr)+').csv', 'x').close()
            created = True
            file_path = log_folder+time+'-repair-log('+str(ctr)+').csv'
        else:
            ctr += 1

    # Writes the data to the file.
    with open(file_path, 'w') as opened_file:
        csv_file = csv.writer(opened_file)
        for row in csv_data:
            csv_file.writerow(row)
    return file_path


# Sends the email with the formatted data using the SMTP server
def SendCSV(recipent, file_to_send):

    # Defining information required to send the email.
    sender = 'noreply.repair.logger@nisd.net'
    subject = 'Repair Log From Last Entry'
    server = 'ec2-p-smtp02.nisd.net'
    text = 'Here are your logged repairs.'

    # Assigns email information to msg object.
    msg = MIMEMultipart()
    msg['From'] = sender
    msg['To'] = recipent
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject
    msg.attach(MIMEText(text))

    # Retrieves file and attatches it to 'part' variable
    with open(file_to_send, "rb") as fil:
        part = MIMEApplication(
            fil.read(),
            Name=basename(file_to_send)
        )

    # Attatch file to 'msg' object.
    part['Content-Disposition'] = 'attachment; filename="%s"' % basename(
        file_to_send)
    msg.attach(part)

    # Send email using 'msg' object and server info.
    smtp = smtplib.SMTP(server)
    smtp.sendmail(sender, recipent, msg.as_string())
    smtp.close()


# The function that calls all the rest, formats the data, saves
# the data, sedns the data and writes the data to the Google Sheet
def LogRepair():
    ctr = 1
    csv_data = FormatCSVData('input.csv')
    saved_csv_name = CreateCSV(csv_data)
    SendCSV('cayne.brister@nisd.net', saved_csv_name)

    for row in csv_data:
        AppendValues(
            "1rP-RKuIfkGB_qps7VclkmBEQW9T2DfwJm64UVcc-4lw", row, token_file)
        ctr += 1


if __name__ == '__main__':
    LogRepair()
